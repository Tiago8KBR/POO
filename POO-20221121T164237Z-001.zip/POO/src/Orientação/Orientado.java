package Orientação;

public class Orientado {

}
