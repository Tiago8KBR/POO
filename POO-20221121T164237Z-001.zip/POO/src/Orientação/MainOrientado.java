package Orientação;

public class MainOrientado {

}
