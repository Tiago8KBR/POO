package Orientação;

public interface Orientando {

}
